package com.vkaksha;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VkakshaApplication {

	public static void main(String[] args) {
		SpringApplication.run(VkakshaApplication.class, args);
	}

}
